package com.example.lab2_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements Arina2.OnFragmentInteractionListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onFragmentInteraction(String link) {

        Output fragment = (Output) getSupportFragmentManager()
                .findFragmentById(R.id.fragment2);
        if (fragment != null && fragment.isInLayout()) {
            fragment.setText(link);
        }
    }
}
