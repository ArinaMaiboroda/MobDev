package com.example.lab2_2;


import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

;


public class Arina2 extends Fragment {
    private OnFragmentInteractionListener mListener;

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(String buffer);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_arina2, container, false);

        Button button = view.findViewById(R.id.orderButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                orderButtonClick();
            }
        });

        return view;

    }
    public void orderButtonClick(){

        // Train time
        final EditText trainTime = (EditText) getView().findViewById(R.id.trainTime);


        // Train name
        final EditText trainName = (EditText) getView().findViewById(R.id.trainName);

        // Button action
        //Context context = getApplicationContext();

        CharSequence trainNameText = trainName.getText().toString();
        CharSequence trainTimeText = trainTime.getText().toString();
        RadioGroup rg = getView().findViewById(R.id.rg_variants);
        RadioButton selected = getView().findViewById(rg.getCheckedRadioButtonId());

        String orderText ="";
        String announcement="";

        if (trainNameText.equals("") || trainTimeText.equals("") || selected == null){
            announcement = "Please fill all the data";
        }
        else {
            orderText = String.format(
                    "Train \"%s\". In %s. On %s.",
                    trainNameText,
                    trainTimeText,
                    selected.getText().toString()
            );

            announcement = "You ordered is accepted.";
        }

        mListener.onFragmentInteraction(orderText);

        Toast toast = Toast.makeText(getActivity().getApplicationContext(), announcement, Toast.LENGTH_LONG);
        toast.show();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mListener = (OnFragmentInteractionListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " должен реализовывать интерфейс OnFragmentInteractionListener");
        }
    }
}
