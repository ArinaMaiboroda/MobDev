package com.example.arinaslab1;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void orderButtonClick(View view){

        // Train time
        final EditText trainTime = (EditText) findViewById(R.id.trainTime);


        // Train name
        final EditText trainName = (EditText) findViewById(R.id.trainName);

        // Button action
        Context context = getApplicationContext();

        CharSequence trainNameText = trainName.getText().toString();
        CharSequence trainTimeText = trainTime.getText().toString();
        String orderText;

        if (trainNameText.equals("") || trainTimeText.equals("")){
            orderText = "Please fill all columns";
        }
        else {
            orderText = String.format(
                    "You ordered is accepted.\nTrain \"%s\". On %s.",
                    trainNameText,
                    trainTimeText
            );
        }

        Toast toast = Toast.makeText(context, orderText, Toast.LENGTH_LONG);
        toast.show();
    }

}